const initialState = {
list:[]
}

const starWarsReducer = (state = initialState, action) => {
  switch(action.type)
  {
    case 'GET_DATA':
      return {
        ...state, 
        list: action.data
      }
    default: 
    return false;
  }
}
 
export default starWarsReducer;