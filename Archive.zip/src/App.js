import React from "react";
import OpenBounties from "./components/OpenBounties";
import BountyDetails from "./components/BountyDetails";
import NavBar from "./components/NavBar";
import './App.css';

function App() {
  return (
   <div >  
    <NavBar />
    <div className="mainDiv">
     <OpenBounties />
     <BountyDetails />
   </div>
   </div>

  )
}

export default App;
