import { GET_DATA } from './actionTypes'; 
import axios from 'axios';

const getDataSuccess = (data) => {
  return {
      type: GET_DATA,
      data: data
  }
}

export const getData = (url) => {
  return (dispatch) => {
      axios.get(url)
      .then(response => {
          dispatch(getDataSuccess(response.data));
      })
      .catch(error => {
          console.log('getData on action Handler messed up')
      })
  }
}