import React from 'react';
const BountyDetails = () => {
  return ( 
  <div className="outline">
  <div><h1 className='openDetailsHeader'>Open Bounties</h1></div>
  </div> );
}
 
export default BountyDetails;