import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getData } from "./../actions/actionHandlers";
import './OpenBounties.css';

const OpenBounties = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getData("https://akabab.github.io/starwars-api/api/all.json"));
  }, []);

  const bounty = useSelector((state) => state.list);
  return (    
  <div className='outline'>
  <div><h1 className='openBountyHeader'>Open Bounties</h1></div>

    <div className="parent">

      {bounty !== undefined
        ? bounty.map((person) =>
            !person.diedLocation ? (
              <div className="personDiv aliveDiv" key={person.id}>
                <div>
                  <img src={person.image} alt="mug_shot" height="150px"></img>
                </div>              
                <div>{person.name}</div>

              </div>
            ) : (
                <div className="personDiv deadDiv" key={person.id}>
                <div>
                  <img src={person.image} alt="mug_shot" height="150px"></img>
                </div>
                <div>{person.name}</div>
                <div>
                  <strong>Deceased</strong>
                  <div>Died on: {person.diedLocation}</div>
                </div>
              </div>
            )
          )
        : ""}
    </div>
    </div>
  );
}

export default OpenBounties;
