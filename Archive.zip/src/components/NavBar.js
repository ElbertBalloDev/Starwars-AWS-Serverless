import React from 'react';
import { Link } from 'react-router-dom';
import './NavBar.css'

const NavBar = () => {
  return ( 
    <div className="navBar">
      <header>
       
          <h3> Bounty Hunter Craiglist</h3>
         
          <div className="row">
            <div className="col">
                <Link to="/" className='btn btn-outline-primary'>Home</Link>
                <Link to="/mybouties" className='btn btn-outline-primary'>My Bouties</Link>
            </div>
        </div>
      </header>
    </div>
   );
}
 
export default NavBar;